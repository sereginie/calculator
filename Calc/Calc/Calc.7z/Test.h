#pragma once

void TestAllFunctions();
void TestSum();
void TestSub();
void TestDiv();
void TestMult();
void TestExpon();
void TestSignMatching();
void TestGetNOD();
void TestGetNOK();